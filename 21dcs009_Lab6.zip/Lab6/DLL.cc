//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License
// along with this program.  If not, see http://www.gnu.org/licenses/.
// 

#include "DLL.h"

Define_Module(DLL);

void DLL::initialize()
{
    // TODO - Generated method body
    id=par("dlId");
    in_n=gate("dlIn_n");
    out_n=gate("dlOut_n");
    in_c=gate("dlIn_c");
    out_c=gate("dlOut_c");
    copy_message=new DL_PDU();
    timeoutEvent=new cMessage("timeoutEvent");
}

void DLL::handleMessage(cMessage *msg)
{
    // TODO - Generated method body
    if(msg==timeoutEvent)
    {
        send(copy_message, out_c);
        cancelEvent(timeoutEvent);
        scheduleAt(simTime()+200, timeoutEvent);
    }
    else if(msg->getArrivalGate()==in_n)
    {
        DL_PDU *p=new DL_PDU();
        N_PDU *p1=check_and_cast<N_PDU*>(msg);
        p -> encapsulate(p1);
        p -> setDL_PDU_PktType(1);
        send(p, out_c);
        copy_message=p->dup();
        cancelEvent(timeoutEvent);
        scheduleAt(simTime()+200, timeoutEvent);
    }
    else if(msg->getArrivalGate()==in_c)
    {
        DL_PDU *p2=check_and_cast<DL_PDU*>(msg);
        if(p2->getDL_PDU_PktType()==1)
        {
            p2->decapsulate();
            DL_PDU *ack=new DL_PDU();
            ack->setDL_PDU_PktType(0);

            if(uniform(0, 1)<0.1)
            {
                delete(p2);
            }
            else
            {
                send(p2, out_n);
                send(ack, out_c);
            }
        }
        else
        {
            cancelEvent(timeoutEvent);
            delete(msg);
        }
    }
}
