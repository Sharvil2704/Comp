#ifndef __LAB7_NODE_H_
#define __LAB7_NODE_H_

#include<omnetpp.h>
#include <map>
#include<N_PDU_m.h>
using namespace omnetpp;
using namespace std;

/**
 * TODO - Generated class
 */
class Node : public cSimpleModule
{
  protected:


    int address;
    int source_address;
    int dest_address;
    cGate* in;
    cGate* out;
    map <int,int> LUT;
    virtual void initialize() override;
    virtual void handleMessage(cMessage *msg) override;
};

#endif
