#include "Node.h"

Define_Module(Node);

void Node::initialize()
{
    dest_address=par("dest_address");
    source_address=par("source_address");
    address=par("address");

    if(address==0){
        LUT = {{1,0},{2,0},{3,0},{4,0}};
    }
    else if(address==1){
        LUT = {{0,0},{2,1},{3,2},{4,1}};
    }
    else if(address==2){
        LUT = {{0,0},{1,0},{3,1},{4,1}};
    }
    else if(address==3){
        LUT = {{0,0},{1,0},{2,1},{4,1}};
    }
    else if(address==4){
        LUT = {{0,0},{1,1},{2,2},{3,1}};
    }

    if(address==source_address){
        cMessage* event = new cMessage();
        scheduleAt(0,event);
    }
}

void Node::handleMessage(cMessage *msg)
{
    if(msg->isSelfMessage()){
        N_PDU* data = new N_PDU();
        data->setStart(simTime());
        send(data,"gout",LUT.at(dest_address));
    }
    else{
        if(address==dest_address){
            N_PDU* data = check_and_cast<N_PDU*>(msg);
            EV<<"Delay"<<data->getArrivalTime() - data->getStart();
        }
        else{
            N_PDU* data = check_and_cast<N_PDU*>(msg);
            send(data,"gout",LUT.at(dest_address));
        }
    }


}
