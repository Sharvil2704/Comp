//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License
// along with this program.  If not, see http://www.gnu.org/licenses/.
// 

#include "NL.h"

Define_Module(NL);

void NL::initialize()
{
    // TODO - Generated method body
    id=par("nId");
    remainingPackets=par("remainingPackets");
    source=par("source");
    in=gate("nIn");
    out=gate("nOut");

    if(id==source && remainingPackets!=0)
    {
        cMessage *event=new cMessage();
        scheduleAt(0, event);
    }

}

void NL::handleMessage(cMessage *msg)
{
    // TODO - Generated method body
    if(msg -> isSelfMessage())
    {
        N_PDU *p=new N_PDU();
        if(remainingPackets==0)
        {
            return;
        }

        p -> setN_PDU_PktId((remainingPackets--)%2);
        p -> setN_PDU_PktType(1);

        send(p, out);
        cMessage *event=new cMessage();
        scheduleAt(simTime()+200, event);
    }
    else
    {
        delete(msg);
    }
}
