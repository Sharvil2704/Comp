//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License
// along with this program.  If not, see http://www.gnu.org/licenses/.
// 

#include "Data_Link_Layer.h"

Define_Module(Data_Link_Layer);

void Data_Link_Layer::initialize()
{
    // TODO - Generated method body
    address = par("data_link_id");
        d_in = gate("data_network_in");
        d_out = gate("data_network_out");

        c_in = gate("data_compound_in");
        c_out = gate("data_compound_out");

}

void Data_Link_Layer::handleMessage(cMessage *msg)
{
    // TODO - Generated method body


    if(msg->getArrivalGate() == d_in){
        N_PDU *A = check_and_cast<N_PDU*> (msg);

        D_PDU *d = new D_PDU();

        d->encapsulate(A);
        d->setD_packet_type("Data");

        send(d, c_out);
    }
    else if (msg->getArrivalGate() == c_in){
        D_PDU *S = check_and_cast<D_PDU*> (msg);
        if (strcmp( S->getD_packet_type() , "Data")== 0){
             S->decapsulate();

             D_PDU *ack = new D_PDU();
             ack->setD_packet_id(1);
             ack->setD_packet_type("Ack");

             send(S, d_out);
             send(ack, c_out);
             }
    }
    else {
        delete(msg);
    }
}
